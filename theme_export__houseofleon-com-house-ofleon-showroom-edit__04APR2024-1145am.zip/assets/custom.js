/*
 * Broadcast Theme
 *
 * Use this file to add custom Javascript to Broadcast.  Keeping your custom
 * Javascript in this fill will make it easier to update Broadcast. In order
 * to use this file you will need to open layout/theme.liquid and uncomment
 * the custom.js script import line near the bottom of the file.
 */

document.addEventListener("DOMContentLoaded", function () {
  var hiddenInput = document.getElementsByName("id")[0];
  if (hiddenInput) {
    hiddenInput.addEventListener("change", function () {
      var updatedValue = hiddenInput.value;

      console.log("Hidden input value changed:", updatedValue);
      let metaQuant = document.querySelectorAll(".meta-quant");
      let metaAsterisk = document.querySelectorAll(".meta-asterisk");
      let metaShipping = document.querySelectorAll(".meta-shipping");

      metaQuant.forEach(function (element) {
        if (element.getAttribute("data-varid") === updatedValue) {
          element.style.display = "block";
        } else {
          element.style.display = "none";
        }
      });
      metaAsterisk.forEach(function (element) {
        if (element.getAttribute("data-varid") === updatedValue) {
          element.style.display = "block";
        } else {
          element.style.display = "none";
        }
      });
      metaShipping.forEach(function (element) {
        if (element.getAttribute("data-varid") === updatedValue) {
          element.style.display = "block";
        } else {
          element.style.display = "none";
        }
      });
    });
  }
});
